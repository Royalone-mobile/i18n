window.i18n.en_us = {
	header: 'i18n jQuery Plug-in',
	select: 'Change Language',
	username: 'Username',
	password: 'Password',
	enter_username: 'Enter Username',
	enter_password: 'Enter Password',
	submit: 'Submit',
	source: 'Check out the HTML source to see how this is being used.  Its sweet!'
}
