window.i18n.ja_jp = {
	header: 'i18n jQuery Plug-in',
	select: '言語を変更',
	username: 'ユーザー名',
	password: 'パスワード',
	enter_username: 'ユーザー名を入力してください',
	enter_password: 'パスワードを入力',
	submit: '提出する',
	source: 'これが使用されているかを確認するには、HTMLソースをチェックしてください。その甘い！'
}
