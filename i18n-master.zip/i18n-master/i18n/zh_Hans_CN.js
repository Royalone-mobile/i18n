document.ResourceMap={
	"T_SELECT_LANG":"选择语言：",
	"T_USERNAME":"用户名：",
	"T_PASSWORD":"密码："
	}

