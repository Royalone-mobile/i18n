document.ResourceMap={
	"T_SELECT_LANG":"Select Language:",
	"T_USERNAME":"Username:",
	"T_PASSWORD":"Password:"
	
}

